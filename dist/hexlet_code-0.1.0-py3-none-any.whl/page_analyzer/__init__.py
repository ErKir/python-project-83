from page_analyzer.app import app   # noqa: F401

__all__ = 'app'
